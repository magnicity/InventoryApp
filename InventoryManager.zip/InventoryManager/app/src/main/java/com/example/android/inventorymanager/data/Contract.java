package com.example.android.inventorymanager.data;

import android.provider.BaseColumns;

public class Contract {
    // To prevent someone from accidentally instantiating the contract class,
    // give it an empty constructor.
    private Contract() {}

    /**
     * Inner class that defines constant values for the pets database table.
     * Each entry in the table represents a single pet.
     */
    public static final class ItemEntry implements BaseColumns {

        /** Name of database table for pets */
        public final static String TABLE_NAME = "items";

        /**
         * Unique ID number for the pet (only for use in the database table).
         *
         * Type: INTEGER
         */
        public final static String _ID = BaseColumns._ID;

        /**         *
         * Type: TEXT
         */
        public final static String COLUMN_ITEM_NAME ="Product";

        /**
         *
         * Type: TEXT
         */
        public final static String COLUMN_ITEM_PRICE = "Price";

        /**
         *    Type: INTEGER
         */
        public final static String COLUMN_ITEM_QUANTITY = "Quantity";


        public final static String COLUMN_SUPPLIER_NAME = "Supplier Name";
        /**
         */
        public final static String COLUMN_SUPPLIER_NUMBER = "Supplier Number";

    }

}

